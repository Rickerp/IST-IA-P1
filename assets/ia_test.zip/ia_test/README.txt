Olá meu caro.

Gerar inputs do enunciado. Editar o ficheiro gen.py para inputs manuais.
>> python gen.py enunciado.in

Gerar inputs válidos aleatórios. Editar a classe `Config` com configurações a gosto.
>> python gen_valid.py valid.in

Testar a solução com um input:
-- Instalar package `tabulate`: pip install tabulate
-- Colar a solução dentro do `solution.py`

>> python test.py enunciado.in
>> python test.py valid.n --map

-- Ver a pasta criada: output