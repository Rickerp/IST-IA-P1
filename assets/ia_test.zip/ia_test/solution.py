from math import inf

class SearchProblem:
	def __init__(self, goal, model, auxheur=None):
		pass

	def search(self, init, limitexp=2000, limitdepth=10, tickets=(inf, inf, inf), anyorder=False):
		return []